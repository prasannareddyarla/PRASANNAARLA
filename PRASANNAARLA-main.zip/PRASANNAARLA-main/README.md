## Hi 👋 I'm Prasanna Arla ##

• I am from India and currently pursuing Master's in Applied Computer Science at Northwest Missouri State University.

## My current courses are:  💻 ##  

1. Patterns and Frameworks
2. Mobile Computiing-iOS
3. Graduate Direct Project

## Area of Intrests ##
1. I am instrested in Programming, Data Structures, Artificial Intelligence.
   * Languages I am goot at are C, Java and Python.
2. Apart from these personally I am also intrested in arts and science .

## About Me  😊 ## 
* I have completed my bachelore's in the year of 2019 and I have worked in an Multi National Comapany named Cognizant Technologies as Quality Analyst for an year on Artificial Intelligence technolgy. 
* There after my intrest in studying Master's in United States from schooling has bought me here and here in this university the courses are pretty much intrested and I am able to learn new technologies which would be very helpful for my career. 
* And also apart from studiest, I love travelling different places to explore the things.
* Collaborating on GDP .

## Permanent Email
 * My personal email id : prasannareddyarla@gmail.com 